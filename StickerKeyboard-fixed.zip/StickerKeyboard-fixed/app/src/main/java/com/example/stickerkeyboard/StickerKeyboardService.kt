package com.example.stickerkeyboard

import android.content.ClipData
import android.content.ClipDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File

class StickerKeyboardService : InputMethodService() {

    private enum class KeyboardMode { EN, AR, SYMBOLS, STICKERS }

    private var keyboardMode = KeyboardMode.EN
    private var lastTyping = KeyboardMode.EN
    private var shiftOn = false
    private var acceptedMimeTypes: Array<String> = emptyArray()
    private var lastEditorInfo: EditorInfo? = null
    private val uiHandler = Handler(Looper.getMainLooper())

    private lateinit var keysContainer: LinearLayout
    private lateinit var statusView: TextView

    private fun keysOf(s: String): List<String> = s.map { it.toString() }

    private val enRows: List<List<String>> = listOf(
        keysOf("qwertyuiop"),
        keysOf("asdfghjkl"),
        keysOf("zxcvbnm")
    )

    private val arRows: List<List<String>> = listOf(
        keysOf("ضصثقفغعهخحجد"),
        keysOf("شسيبلاتنمكط"),
        keysOf("ذئءؤر") + "لا" + keysOf("ىةوزظأ")
    )

    private val symRows: List<List<String>> = listOf(
        keysOf("1234567890"),
        keysOf("@#\$_&-+()/"),
        keysOf("*\"':;!?=%")
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setBackgroundColor(Color.parseColor("#ECEFF1"))
        root.setPadding(dp(3), dp(3), dp(3), dp(4))

        val toolbar = LinearLayout(this)
        toolbar.orientation = LinearLayout.HORIZONTAL
        toolbar.gravity = Gravity.CENTER_VERTICAL
        toolbar.addView(makeButton("Aa", "#B0BEC5", 14f) { switchMode(lastTyping) }, actionParams(48))
        toolbar.addView(makeButton("ستيكرات", "#A5D6A7", 14f) { switchMode(KeyboardMode.STICKERS) }, actionParams(72))
        toolbar.addView(makeButton("تبديل", "#B0BEC5", 14f) { showPicker() }, actionParams(56))
        toolbar.addView(makeButton("التطبيق", "#B0BEC5", 14f) { openApp() }, actionParams(64))

        statusView = TextView(this)
        statusView.textSize = 12f
        statusView.setTextColor(Color.DKGRAY)
        statusView.maxLines = 1
        statusView.ellipsize = TextUtils.TruncateAt.END
        statusView.setPadding(dp(6), 0, dp(6), 0)
        statusView.text = ""
        toolbar.addView(statusView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        root.addView(
            toolbar,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        keysContainer = LinearLayout(this)
        keysContainer.orientation = LinearLayout.VERTICAL
        root.addView(
            keysContainer,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        renderKeys()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        lastEditorInfo = info
        acceptedMimeTypes = if (info != null) EditorInfoCompat.getContentMimeTypes(info) else emptyArray()
        shiftOn = false
        if (::keysContainer.isInitialized) {
            renderKeys()
        }
        showStatus("")
    }

    // ---------- UI helpers ----------

    private fun makeButton(label: String, bg: String, size: Float = 17f, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setAllCaps(false)
        b.textSize = size
        b.setTextColor(Color.BLACK)
        b.minWidth = 0
        b.minHeight = 0
        b.minimumWidth = 0
        b.minimumHeight = 0
        b.setPadding(0, 0, 0, 0)
        val shape = GradientDrawable()
        shape.setColor(Color.parseColor(bg))
        shape.cornerRadius = dp(6).toFloat()
        b.background = shape
        b.setOnClickListener { onClick() }
        return b
    }

    private fun keyParams(weight: Float): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(0, dp(46), weight)
        p.setMargins(dp(2), dp(3), dp(2), dp(3))
        return p
    }

    private fun actionParams(widthDp: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(dp(widthDp), dp(38))
        p.setMargins(dp(2), dp(2), dp(2), dp(2))
        return p
    }

    private fun rowParams(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    }

    private fun newRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.layoutDirection = if (keyboardMode == KeyboardMode.AR) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        return row
    }

    private fun showStatus(text: String) {
        if (::statusView.isInitialized) {
            statusView.text = text
        }
    }

    private fun switchMode(newMode: KeyboardMode) {
        keyboardMode = newMode
        if (newMode == KeyboardMode.EN || newMode == KeyboardMode.AR) {
            lastTyping = newMode
        }
        shiftOn = false
        renderKeys()
    }

    private fun renderKeys() {
        keysContainer.removeAllViews()
        if (keyboardMode == KeyboardMode.STICKERS) {
            renderStickers()
        } else {
            renderTyping()
        }
    }

    // ---------- Typing keyboard ----------

    private fun renderTyping() {
        val rows: List<List<String>> = when (keyboardMode) {
            KeyboardMode.AR -> arRows
            KeyboardMode.SYMBOLS -> symRows
            else -> enRows
        }

        for ((index, keys) in rows.withIndex()) {
            val row = newRow()
            if (keyboardMode == KeyboardMode.EN && index == 2) {
                val shiftLabel = if (shiftOn) "AA" else "Aa"
                val shiftColor = if (shiftOn) "#90CAF9" else "#CFD8DC"
                row.addView(makeButton(shiftLabel, shiftColor, 15f) { toggleShift() }, keyParams(1.5f))
            }
            for (k in keys) {
                val label = if (keyboardMode == KeyboardMode.EN && shiftOn) k.uppercase() else k
                row.addView(makeButton(label, "#FFFFFF") { typeText(label) }, keyParams(1f))
            }
            if (index == 2) {
                row.addView(makeBackspace(), keyParams(1.5f))
            }
            keysContainer.addView(row, rowParams())
        }

        val bottom = newRow()
        val isSymbols = keyboardMode == KeyboardMode.SYMBOLS
        val isArabic = keyboardMode == KeyboardMode.AR

        bottom.addView(
            makeButton(if (isSymbols) "ABC" else "123", "#CFD8DC", 15f) {
                switchMode(if (isSymbols) lastTyping else KeyboardMode.SYMBOLS)
            },
            keyParams(1.3f)
        )
        bottom.addView(
            makeButton(if (isArabic) "EN" else "عربي", "#CFD8DC", 15f) {
                switchMode(if (isArabic) KeyboardMode.EN else KeyboardMode.AR)
            },
            keyParams(1.3f)
        )
        val comma = if (isArabic) "،" else ","
        bottom.addView(makeButton(comma, "#FFFFFF") { typeText(comma) }, keyParams(1f))
        bottom.addView(
            makeButton(if (isArabic) "مسافة" else "space", "#FFFFFF", 14f) { typeText(" ") },
            keyParams(4f)
        )
        val dot = if (isArabic) "؟" else "."
        bottom.addView(makeButton(dot, "#FFFFFF") { typeText(dot) }, keyParams(1f))
        bottom.addView(makeButton("Enter", "#CFD8DC", 13f) { pressEnter() }, keyParams(1.6f))
        keysContainer.addView(bottom, rowParams())
    }

    private fun toggleShift() {
        shiftOn = !shiftOn
        renderKeys()
    }

    private fun typeText(text: String) {
        currentInputConnection?.commitText(text, 1)
        if (shiftOn) {
            shiftOn = false
            renderKeys()
        }
    }

    private fun deleteOne() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (selected != null && selected.length > 0) {
            ic.commitText("", 1)
        } else {
            ic.deleteSurroundingTextInCodePoints(1, 0)
        }
    }

    private fun pressEnter() {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
    }

    private fun makeBackspace(): Button {
        val b = makeButton("←", "#CFD8DC", 18f) { }
        val repeat = object : Runnable {
            override fun run() {
                deleteOne()
                uiHandler.postDelayed(this, 60)
            }
        }
        b.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    deleteOne()
                    uiHandler.postDelayed(repeat, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    uiHandler.removeCallbacks(repeat)
                }
            }
            true
        }
        return b
    }

    // ---------- Sticker library panel ----------

    private fun renderStickers() {
        val items = LibraryStore.list(this)
        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL

        if (items.isEmpty()) {
            val empty = TextView(this)
            empty.text = "لا توجد ستيكرات محفوظة بعد. افتح التطبيق وحوّل فيديو أولاً."
            empty.setTextColor(Color.DKGRAY)
            empty.gravity = Gravity.CENTER
            empty.setPadding(dp(12), dp(40), dp(12), dp(12))
            list.addView(empty)
        }
        for (item in items) {
            list.addView(buildStickerRow(item))
        }

        scroll.addView(list)
        keysContainer.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(208))
        )
    }

    private fun loadThumb(file: File): Bitmap? {
        return try {
            val opts = BitmapFactory.Options()
            opts.inSampleSize = 4
            BitmapFactory.decodeFile(file.absolutePath, opts)
        } catch (e: Throwable) {
            null
        }
    }

    private fun buildStickerRow(item: LibraryItem): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutDirection = View.LAYOUT_DIRECTION_LTR
        row.setPadding(dp(4), dp(3), dp(4), dp(3))

        val thumb = ImageView(this)
        thumb.setImageBitmap(loadThumb(item.webp))
        row.addView(thumb, LinearLayout.LayoutParams(dp(48), dp(48)))

        val name = TextView(this)
        name.text = item.name
        name.textSize = 15f
        name.setTextColor(Color.BLACK)
        name.maxLines = 2
        name.setPadding(dp(8), 0, dp(8), 0)
        row.addView(name, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        row.addView(makeButton("الاثنان", "#C8E6C9", 13f) { sendBoth(item) }, actionParams(62))
        row.addView(makeButton("ستيكر", "#FFFFFF", 13f) { sendSticker(item) }, actionParams(56))
        row.addView(makeButton("صوت", "#FFFFFF", 13f) { sendSound(item) }, actionParams(50))
        return row
    }

    // ---------- Sending ----------

    private fun sendSticker(item: LibraryItem): Boolean {
        val ic = currentInputConnection
        val info = lastEditorInfo
        if (ic == null || info == null) {
            showStatus("لا يوجد حقل كتابة نشط")
            return false
        }
        if (acceptedMimeTypes.none { it.startsWith("image/webp") }) {
            showStatus("هذا التطبيق لا يقبل ستيكرات من الكيبورد")
            return false
        }
        val mime = if (acceptedMimeTypes.contains("image/webp.wasticker")) {
            "image/webp.wasticker"
        } else {
            "image/webp"
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", item.webp)
        val content = InputContentInfoCompat(uri, ClipDescription("Sticker", arrayOf(mime)), null)
        var ok = false
        try {
            ok = InputConnectionCompat.commitContent(
                ic, info, content,
                InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
        showStatus(if (ok) "تم إرسال الستيكر" else "فشل إرسال الستيكر")
        return ok
    }

    // Sound goes through Android's share mechanism: WhatsApp accepts no audio from keyboards.
    private fun sendSound(item: LibraryItem) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", item.audio)
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "audio/mp4"
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.clipData = ClipData.newRawUri("audio", uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)

            val target = lastEditorInfo?.packageName
            if (target != null && target.startsWith("com.whatsapp")) {
                intent.setPackage(target)
                startActivity(intent)
            } else {
                val chooser = Intent.createChooser(intent, "إرسال الصوت")
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(chooser)
            }
            showStatus("اختر المحادثة ثم اضغط إرسال")
        } catch (e: Exception) {
            showStatus("تعذر فتح المشاركة: ${e.javaClass.simpleName}")
        }
    }

    private fun sendBoth(item: LibraryItem) {
        if (sendSticker(item)) {
            uiHandler.postDelayed({ sendSound(item) }, 700)
        }
    }

    // ---------- Toolbar actions ----------

    private fun showPicker() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }

    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }
}
