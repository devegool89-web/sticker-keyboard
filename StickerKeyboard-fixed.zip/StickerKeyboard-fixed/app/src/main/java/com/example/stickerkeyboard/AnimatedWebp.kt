package com.example.stickerkeyboard

import java.io.ByteArrayOutputStream

/**
 * Builds an animated WebP file from several still WebP images.
 * This avoids needing the libwebp encoder inside FFmpeg (it is missing in the FFmpegKit build).
 */
object AnimatedWebp {

    private fun le32(n: Int): ByteArray = byteArrayOf(
        (n and 0xFF).toByte(),
        ((n shr 8) and 0xFF).toByte(),
        ((n shr 16) and 0xFF).toByte(),
        ((n shr 24) and 0xFF).toByte()
    )

    private fun le24(n: Int): ByteArray = byteArrayOf(
        (n and 0xFF).toByte(),
        ((n shr 8) and 0xFF).toByte(),
        ((n shr 16) and 0xFF).toByte()
    )

    private fun le16(n: Int): ByteArray = byteArrayOf(
        (n and 0xFF).toByte(),
        ((n shr 8) and 0xFF).toByte()
    )

    private fun readLe32(b: ByteArray, pos: Int): Int =
        (b[pos].toInt() and 0xFF) or
            ((b[pos + 1].toInt() and 0xFF) shl 8) or
            ((b[pos + 2].toInt() and 0xFF) shl 16) or
            ((b[pos + 3].toInt() and 0xFF) shl 24)

    private fun fourCc(b: ByteArray, pos: Int): String =
        String(b, pos, 4, Charsets.US_ASCII)

    private fun chunk(id: String, payload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(id.toByteArray(Charsets.US_ASCII))
        out.write(le32(payload.size))
        out.write(payload)
        if (payload.size % 2 == 1) {
            out.write(0)
        }
        return out.toByteArray()
    }

    /** Returns only the image-data chunks (ALPH, VP8, VP8L) of a still WebP file. */
    private fun frameChunks(webp: ByteArray): ByteArray {
        require(webp.size > 12 && fourCc(webp, 0) == "RIFF" && fourCc(webp, 8) == "WEBP") {
            "Not a WebP file"
        }
        val out = ByteArrayOutputStream()
        var pos = 12
        while (pos + 8 <= webp.size) {
            val id = fourCc(webp, pos)
            val size = readLe32(webp, pos + 4)
            val padded = size + (size % 2)
            if (size < 0 || pos + 8 + padded > webp.size) {
                break
            }
            if (id == "ALPH" || id == "VP8 " || id == "VP8L") {
                out.write(webp, pos, 8 + padded)
            }
            pos += 8 + padded
        }
        require(out.size() > 0) { "No image data found in WebP frame" }
        return out.toByteArray()
    }

    fun mux(frames: List<ByteArray>, width: Int, height: Int, frameDurationMs: Int): ByteArray {
        require(frames.isNotEmpty()) { "No frames" }
        val body = ByteArrayOutputStream()
        body.write("WEBP".toByteArray(Charsets.US_ASCII))

        // VP8X: flags 0x12 = alpha + animation, then canvas size minus one
        body.write(chunk("VP8X", byteArrayOf(0x12, 0, 0, 0) + le24(width - 1) + le24(height - 1)))
        // ANIM: background colour 0, loop count 0 = forever
        body.write(chunk("ANIM", le32(0) + le16(0)))

        for (frame in frames) {
            val payload = ByteArrayOutputStream()
            payload.write(le24(0))                 // x offset / 2
            payload.write(le24(0))                 // y offset / 2
            payload.write(le24(width - 1))
            payload.write(le24(height - 1))
            payload.write(le24(frameDurationMs))
            payload.write(0x02)                    // do not blend, do not dispose
            payload.write(frameChunks(frame))
            body.write(chunk("ANMF", payload.toByteArray()))
        }

        val bodyBytes = body.toByteArray()
        val out = ByteArrayOutputStream()
        out.write("RIFF".toByteArray(Charsets.US_ASCII))
        out.write(le32(bodyBytes.size))
        out.write(bodyBytes)
        return out.toByteArray()
    }
}
