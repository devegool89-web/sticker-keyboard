package com.example.stickerkeyboard

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arthenica.ffmpegkit.FFmpegKit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private var selectedVideoUri: Uri? = null
    private lateinit var tvStatus: TextView
    private lateinit var btnProcess: Button
    private lateinit var etName: EditText
    private lateinit var libraryContainer: LinearLayout
    private var mediaPlayer: MediaPlayer? = null

    private val pickVideoLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            selectedVideoUri = uri
            btnProcess.isEnabled = true
            tvStatus.text = "Status: Video selected"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnPickVideo = findViewById<Button>(R.id.btnPickVideo)
        btnProcess = findViewById<Button>(R.id.btnProcess)
        val etStartTime = findViewById<EditText>(R.id.etStartTime)
        val etDuration = findViewById<EditText>(R.id.etDuration)
        tvStatus = findViewById<TextView>(R.id.tvStatus)
        etName = findViewById<EditText>(R.id.etName)
        libraryContainer = findViewById<LinearLayout>(R.id.libraryContainer)

        installCrashLogger()
        showDiagnostics()
        refreshLibrary()

        btnPickVideo.setOnClickListener {
            pickVideoLauncher.launch("video/*")
        }

        btnProcess.setOnClickListener {
            val uri = selectedVideoUri ?: return@setOnClickListener
            val start = etStartTime.text.toString()
            val duration = etDuration.text.toString()
            val name = etName.text.toString().trim()
            processVideo(uri, start, duration, name)
        }
    }

    // Saves any Java crash to a file so it can be shown on the next launch.
    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                File(filesDir, "crash.txt").writeText(Log.getStackTraceString(throwable))
            } catch (ignored: Throwable) {
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    // Remembers the step being executed, so even a native crash can be located.
    private fun setStage(stage: String) {
        try {
            File(filesDir, "stage.txt").writeText(stage)
        } catch (ignored: Throwable) {
        }
    }

    private fun showDiagnostics() {
        val sb = StringBuilder("Status: Waiting\nABI: ${Build.SUPPORTED_ABIS.joinToString()}")
        val stageFile = File(filesDir, "stage.txt")
        if (stageFile.exists()) {
            val stage = stageFile.readText()
            if (stage != "done") sb.append("\nLast run died during: $stage")
            stageFile.delete()
        }
        val crashFile = File(filesDir, "crash.txt")
        if (crashFile.exists()) {
            sb.append("\nCrash:\n").append(crashFile.readText().take(1500))
            crashFile.delete()
        }
        tvStatus.text = sb.toString()
    }

    // Encodes one PNG frame as a still lossy WebP image using Android's own encoder.
    @Suppress("DEPRECATION")
    private fun encodeStill(png: File, quality: Int): ByteArray {
        val bitmap = BitmapFactory.decodeFile(png.absolutePath)
            ?: throw IllegalStateException("Cannot decode frame ${png.name}")
        try {
            val out = ByteArrayOutputStream()
            val format = if (Build.VERSION.SDK_INT >= 30) {
                Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                Bitmap.CompressFormat.WEBP
            }
            bitmap.compress(format, quality, out)
            return out.toByteArray()
        } finally {
            bitmap.recycle()
        }
    }

    // Builds the animated sticker; lowers quality until it fits the 500KB sticker limit.
    private fun buildAnimatedSticker(frames: List<File>, outFile: File): String {
        val qualities = intArrayOf(80, 60, 45, 30)
        var usedQuality = 0
        var finalSize = 0
        for (q in qualities) {
            val stills = frames.map { encodeStill(it, q) }
            val data = AnimatedWebp.mux(stills, 512, 512, 67)
            outFile.writeBytes(data)
            usedQuality = q
            finalSize = data.size
            if (data.size <= 500 * 1024) {
                break
            }
        }
        return "frames=${frames.size}, quality=$usedQuality, size=${finalSize / 1024}KB"
    }

    private fun processVideo(uri: Uri, startInput: String, durationInput: String, nameInput: String) {
        val start = startInput.filter { it.isDigit() || it == ':' || it == '.' }.ifBlank { "00:00:00" }
        val durationValue = (durationInput.toDoubleOrNull() ?: 3.0).coerceIn(0.5, 8.0)
        tvStatus.text = "Status: Processing..."
        btnProcess.isEnabled = false

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                setStage("copying video")
                val inputTempFile = File(cacheDir, "input_temp.mp4")
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(inputTempFile).use { output ->
                        input.copyTo(output)
                    }
                }

                val stickersDir = File(filesDir, "stickers")
                if (!stickersDir.exists()) {
                    stickersDir.mkdirs()
                }

                val framesDir = File(cacheDir, "frames")
                framesDir.deleteRecursively()
                framesDir.mkdirs()

                val outWebp = File(stickersDir, "sticker.webp")
                val outAudio = File(stickersDir, "audio.m4a")

                if (outWebp.exists()) outWebp.delete()
                if (outAudio.exists()) outAudio.delete()

                val framesCmd = "-ss $start -t $durationValue -i \"${inputTempFile.absolutePath}\" -vf \"fps=15,scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black@0\" -an -y \"${framesDir.absolutePath}/f_%03d.png\""
                val audioCmd = "-ss $start -t $durationValue -i \"${inputTempFile.absolutePath}\" -vn -c:a aac -b:a 64k -y \"${outAudio.absolutePath}\""

                setStage("extracting frames")
                val framesSession = FFmpegKit.execute(framesCmd)
                setStage("extracting audio")
                val audioSession = FFmpegKit.execute(audioCmd)

                val framesRet = framesSession.returnCode?.value
                val audioRet = audioSession.returnCode?.value

                if (framesRet != 0 || audioRet != 0) {
                    setStage("done")
                    val framesLogs = (framesSession.allLogsAsString ?: "").takeLast(700)
                    val audioLogs = (audioSession.allLogsAsString ?: "").takeLast(500)
                    withContext(Dispatchers.Main) {
                        tvStatus.text = "Status: FFmpeg Error (frames=$framesRet, audio=$audioRet)\n--- frames ---\n$framesLogs\n--- audio ---\n$audioLogs"
                        btnProcess.isEnabled = true
                    }
                    return@launch
                }

                setStage("encoding webp")
                val frameFiles = (framesDir.listFiles() ?: emptyArray())
                    .filter { it.name.endsWith(".png") }
                    .sortedBy { it.name }
                if (frameFiles.isEmpty()) {
                    throw IllegalStateException("FFmpeg produced no frames")
                }
                val info = buildAnimatedSticker(frameFiles, outWebp)
                framesDir.deleteRecursively()

                setStage("saving to library")
                val savedName = if (nameInput.isNotEmpty()) {
                    nameInput
                } else {
                    "Sticker ${LibraryStore.list(this@MainActivity).size + 1}"
                }
                LibraryStore.add(this@MainActivity, savedName, outWebp, outAudio)

                setStage("done")
                withContext(Dispatchers.Main) {
                    tvStatus.text = "Status: Saved \"$savedName\" to your library. WebP: $info | Audio: ${outAudio.length() / 1024}KB"
                    etName.setText("")
                    refreshLibrary()
                    btnProcess.isEnabled = true
                }
            } catch (e: Throwable) {
                setStage("done")
                withContext(Dispatchers.Main) {
                    tvStatus.text = "Status: Error - ${e.javaClass.simpleName}: ${e.message}"
                    btnProcess.isEnabled = true
                }
            }
        }
    }

    // ---------- Library ----------

    private fun refreshLibrary() {
        libraryContainer.removeAllViews()
        val items = LibraryStore.list(this)
        if (items.isEmpty()) {
            val empty = TextView(this)
            empty.text = "No saved stickers yet."
            libraryContainer.addView(empty)
            return
        }
        for (item in items) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL

            val title = TextView(this)
            title.text = item.name
            title.textSize = 16f
            row.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            val play = Button(this)
            play.text = "Play"
            play.setOnClickListener { playAudio(item.audio) }
            row.addView(play)

            val del = Button(this)
            del.text = "Delete"
            del.setOnClickListener { confirmDelete(item) }
            row.addView(del)

            libraryContainer.addView(row)
        }
    }

    private fun confirmDelete(item: LibraryItem) {
        AlertDialog.Builder(this)
            .setMessage("Delete \"${item.name}\"?")
            .setPositiveButton("Delete") { _, _ ->
                LibraryStore.delete(this, item.id)
                refreshLibrary()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun playAudio(file: File) {
        try {
            mediaPlayer?.release()
            val player = MediaPlayer()
            player.setDataSource(file.absolutePath)
            player.prepare()
            player.start()
            mediaPlayer = player
        } catch (e: Throwable) {
            tvStatus.text = "Status: Cannot play audio - ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    override fun onDestroy() {
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }
}
