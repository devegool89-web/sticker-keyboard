package com.example.stickerkeyboard

import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arthenica.ffmpegkit.FFmpegKit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private var selectedVideoUri: Uri? = null
    private lateinit var tvStatus: TextView
    private lateinit var btnProcess: Button

    private val pickVideoLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            selectedVideoUri = uri
            btnProcess.isEnabled = true
            tvStatus.text = "Status: Video selected"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnPickVideo = findViewById<Button>(R.id.btnPickVideo)
        btnProcess = findViewById<Button>(R.id.btnProcess)
        val etStartTime = findViewById<EditText>(R.id.etStartTime)
        val etDuration = findViewById<EditText>(R.id.etDuration)
        tvStatus = findViewById<TextView>(R.id.tvStatus)

        installCrashLogger()
        showDiagnostics()

        btnPickVideo.setOnClickListener {
            pickVideoLauncher.launch("video/*")
        }

        btnProcess.setOnClickListener {
            val uri = selectedVideoUri ?: return@setOnClickListener
            val start = etStartTime.text.toString()
            val duration = etDuration.text.toString()
            processVideo(uri, start, duration)
        }
    }

    // Saves any Java crash to a file so it can be shown on the next launch.
    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                File(filesDir, "crash.txt").writeText(Log.getStackTraceString(throwable))
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    // Remembers the step being executed, so even a native crash can be located.
    private fun setStage(stage: String) {
        try {
            File(filesDir, "stage.txt").writeText(stage)
        } catch (_: Throwable) {
        }
    }

    private fun showDiagnostics() {
        val sb = StringBuilder("Status: Waiting\nABI: ${Build.SUPPORTED_ABIS.joinToString()}")
        val stageFile = File(filesDir, "stage.txt")
        if (stageFile.exists()) {
            val stage = stageFile.readText()
            if (stage != "done") sb.append("\nLast run died during: $stage")
            stageFile.delete()
        }
        val crashFile = File(filesDir, "crash.txt")
        if (crashFile.exists()) {
            sb.append("\nCrash:\n").append(crashFile.readText().take(1500))
            crashFile.delete()
        }
        tvStatus.text = sb.toString()
    }

    private fun processVideo(uri: Uri, start: String, duration: String) {
        tvStatus.text = "Status: Processing..."
        btnProcess.isEnabled = false

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                setStage("copying video")
                val inputTempFile = File(cacheDir, "input_temp.mp4")
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(inputTempFile).use { output ->
                        input.copyTo(output)
                    }
                }

                val stickersDir = File(filesDir, "stickers")
                if (!stickersDir.exists()) {
                    stickersDir.mkdirs()
                }

                val outWebp = File(stickersDir, "sticker.webp")
                val outAudio = File(stickersDir, "audio.m4a")

                if (outWebp.exists()) outWebp.delete()
                if (outAudio.exists()) outAudio.delete()

                val webpCmd = "-ss $start -t $duration -i \"${inputTempFile.absolutePath}\" -vf \"fps=15,scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=transparent\" -c:v libwebp -lossless 0 -q:v 50 -loop 0 -an -y \"${outWebp.absolutePath}\""
                val audioCmd = "-ss $start -t $duration -i \"${inputTempFile.absolutePath}\" -vn -c:a aac -b:a 64k -y \"${outAudio.absolutePath}\""

                setStage("loading FFmpeg and creating webp")
                val webpSession = FFmpegKit.execute(webpCmd)
                setStage("extracting audio")
                val audioSession = FFmpegKit.execute(audioCmd)
                setStage("done")

                withContext(Dispatchers.Main) {
                    val webpRet = webpSession.returnCode?.value
                    val audioRet = audioSession.returnCode?.value
                    if (webpRet == 0 && audioRet == 0) {
                        tvStatus.text = "Status: Success! WebP size: ${outWebp.length() / 1024}KB"
                    } else {
                        val webpLogs = (webpSession.allLogsAsString ?: "").takeLast(700)
                        val audioLogs = (audioSession.allLogsAsString ?: "").takeLast(500)
                        tvStatus.text = "Status: FFmpeg Error (webp=$webpRet, audio=$audioRet)\n--- webp ---\n$webpLogs\n--- audio ---\n$audioLogs"
                    }
                    btnProcess.isEnabled = true
                }
            } catch (e: Throwable) {
                setStage("done")
                withContext(Dispatchers.Main) {
                    tvStatus.text = "Status: Error - ${e.javaClass.simpleName}: ${e.message}"
                    btnProcess.isEnabled = true
                }
            }
        }
    }
}
