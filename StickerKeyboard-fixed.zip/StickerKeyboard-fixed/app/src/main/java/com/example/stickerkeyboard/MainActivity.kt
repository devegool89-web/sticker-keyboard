package com.example.stickerkeyboard

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var libraryContainer: LinearLayout
    private lateinit var status: TextView
    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val i = Intent(this, VideoEditorActivity::class.java).putExtra("video_uri", uri)
            startActivityForResult(i, 100)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshLibrary()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(16)); layoutDirection=View.LAYOUT_DIRECTION_RTL }
        root.addView(TextView(this).apply { text="Sticker Keyboard"; textSize=26f; setTextColor(android.graphics.Color.BLACK) }, lp(-1,-2))
        root.addView(TextView(this).apply { text="أنشئ ستيكر متحرك 512×512 من أي فيديو، مع صوت مرتبط بنفس المقطع."; textSize=14f }, lp(-1,-2))
        val pick=Button(this).apply { text="اختيار فيديو وفتح المحرر"; setOnClickListener { pickVideo.launch("video/*") } }
        root.addView(pick, lp(-1,-2))
        status=TextView(this).apply { text="اختر فيديو لبدء التحرير."; textSize=13f }
        root.addView(status,lp(-1,-2))
        root.addView(TextView(this).apply { text="الستيكرات المحفوظة"; textSize=19f; setTextColor(android.graphics.Color.BLACK) },lp(-1,-2))
        libraryContainer=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(libraryContainer,lp(-1,-2))
        root.addView(TextView(this).apply { text="بعد الحفظ: فعّل Sticker Keyboard من إعدادات لوحات المفاتيح، ثم افتح لوحة الستيكرات داخل WhatsApp أو التطبيقات التي تقبل محتوى من لوحة المفاتيح."; textSize=13f },lp(-1,-2))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); if(::libraryContainer.isInitialized) refreshLibrary() }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==100&&resultCode==RESULT_OK){status.text="تم إنشاء الستيكر وحفظه في المكتبة.";refreshLibrary()}}

    private fun refreshLibrary() {
        libraryContainer.removeAllViews()
        val items=LibraryStore.list(this)
        if (items.isEmpty()) {
            libraryContainer.addView(
                TextView(this).apply {
                    text = "لا توجد ستيكرات محفوظة بعد."
                    textSize = 14f
                }
            )
            return
        }
        items.forEach { item ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_LTR}
            val img=ImageView(this).apply{setImageBitmap(android.graphics.BitmapFactory.decodeFile(item.webp.absolutePath));scaleType=ImageView.ScaleType.CENTER_INSIDE}
            row.addView(img,LinearLayout.LayoutParams(dp(64),dp(64)))
            val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
            info.addView(TextView(this).apply{text=item.name;textSize=15f})
            val hasAudio=item.audio.exists()&&item.audio.length()>0
            info.addView(TextView(this).apply{text=if(hasAudio)"ستيكر + صوت" else "ستيكر بدون صوت";textSize=12f})
            row.addView(info,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(Button(this).apply{text="حذف";setOnClickListener{LibraryStore.delete(this@MainActivity,item.id);refreshLibrary()}},LinearLayout.LayoutParams(dp(70),-2))
            libraryContainer.addView(row,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(4)})
        }
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun lp(w:Int,h:Int)=LinearLayout.LayoutParams(if(w<0)w else dp(w),if(h<0)h else dp(h))
}
