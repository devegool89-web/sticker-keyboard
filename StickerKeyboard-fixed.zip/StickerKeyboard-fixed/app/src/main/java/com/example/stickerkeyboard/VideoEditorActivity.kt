package com.example.stickerkeyboard

import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arthenica.ffmpegkit.FFmpegKit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class VideoEditorActivity : AppCompatActivity() {
    private lateinit var video: VideoView
    private lateinit var timeline: TimelineRangeView
    private lateinit var crop: CropOverlayView
    private lateinit var tvTimes: TextView
    private lateinit var tvProgress: TextView
    private lateinit var btnCreate: Button
    private lateinit var nameInput: EditText
    private var inputUri: Uri? = null
    private var durationMs = 0L
    private var playing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        inputUri = intent.getParcelableExtra("video_uri")
        if (inputUri == null) { finish(); return }
        buildUi()
        loadVideo()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val title = TextView(this).apply { text = "تحرير الفيديو للستيكر"; textSize = 21f; setTextColor(Color.BLACK) }
        root.addView(title, lp(-1, -2))
        val subtitle = TextView(this).apply { text = "اختر المقطع حتى 8 ثوانٍ، ثم حدّد القص المربع 1:1"; textSize = 13f }
        root.addView(subtitle, lp(-1, -2))

        val previewFrame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        video = VideoView(this)
        previewFrame.addView(video, FrameLayout.LayoutParams(-1, -1))
        crop = CropOverlayView(this)
        previewFrame.addView(crop, FrameLayout.LayoutParams(-1, -1))
        root.addView(previewFrame, LinearLayout.LayoutParams(-1, dp(300)).apply { topMargin = dp(10) })

        timeline = TimelineRangeView(this)
        root.addView(timeline, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(8) })
        tvTimes = TextView(this).apply { textSize = 14f; setTextColor(Color.DKGRAY); gravity = android.view.Gravity.CENTER }
        root.addView(tvTimes, lp(-1, -2))

        val controls = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val back = Button(this).apply { text = "−0.5s"; setOnClickListener { timeline.nudge(-500) } }
        val play = Button(this).apply { text = "▶ / ❚❚"; setOnClickListener { togglePlay() } }
        val forward = Button(this).apply { text = "+0.5s"; setOnClickListener { timeline.nudge(500) } }
        controls.addView(back); controls.addView(play); controls.addView(forward)
        root.addView(controls, lp(-1, -2))

        val cropHelp = TextView(this).apply { text = "القص: اسحب المربع، واسحب الزاوية لتكبير/تصغير. زر إعادة يضعه في المنتصف."; textSize = 13f }
        root.addView(cropHelp, lp(-1, -2))
        val resetCrop = Button(this).apply { text = "إعادة ضبط القص"; setOnClickListener { crop.reset() } }
        root.addView(resetCrop, lp(-1, -2))

        nameInput = EditText(this).apply { hint = "اسم الستيكر (اختياري)" }
        root.addView(nameInput, lp(-1, -2))
        btnCreate = Button(this).apply { text = "إنشاء Sticker"; setOnClickListener { createSticker() } }
        root.addView(btnCreate, lp(-1, -2))
        tvProgress = TextView(this).apply { textSize = 13f; setTextColor(Color.DKGRAY) }
        root.addView(tvProgress, lp(-1, -2))
        setContentView(ScrollView(this).apply { addView(root) })

        timeline.onChanged = { start, end ->
            tvTimes.text = "البداية: ${fmt(start)}   النهاية: ${fmt(end)}   المدة: ${fmt(end - start)}"
            if (playing && (video.currentPosition < start || video.currentPosition > end)) video.seekTo(start.toInt())
        }
    }

    private fun loadVideo() {
        val uri = inputUri ?: return
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1
            r.release()
            if (dur <= 0L) throw IllegalArgumentException("الفيديو غير صالح")
            durationMs = dur
            timeline.setDuration(dur)
            crop.setVideoAspect(w.toFloat() / h.toFloat())
            video.setVideoURI(uri)
            video.setOnPreparedListener { mp ->
                mp.isLooping = false
                timeline.setDuration(durationMs)
                video.seekTo(0)
                video.start(); playing = true
                video.postDelayed(object : Runnable {
                    override fun run() {
                        if (!isFinishing) {
                            val p = video.currentPosition.toLong()
                            if (p >= timeline.endMs) { video.pause(); playing = false; video.seekTo(timeline.startMs.toInt()) }
                            else timeline.setPlayhead(p)
                            video.postDelayed(this, 80)
                        }
                    }
                }, 80)
            }
            video.setOnErrorListener { _, _, _ -> tvProgress.text = "تعذر تشغيل الفيديو."; true }
        } catch (e: Throwable) {
            tvProgress.text = "خطأ: ${e.message}"
            btnCreate.isEnabled = false
        }
    }

    private fun togglePlay() {
        if (video.isPlaying) { video.pause(); playing = false }
        else { if (video.currentPosition.toLong() >= timeline.endMs) video.seekTo(timeline.startMs.toInt()); video.start(); playing = true }
    }

    private fun createSticker() {
        val uri = inputUri ?: return
        val start = timeline.startMs
        val end = timeline.endMs
        if (end <= start || end - start > 8000L) { tvProgress.text = "المدة يجب أن تكون بين 0.5 و8 ثوانٍ."; return }
        btnCreate.isEnabled = false
        video.pause(); playing = false
        lifecycleScope.launch(Dispatchers.IO) {
            val work = File(cacheDir, "editor_${System.currentTimeMillis()}").apply { mkdirs() }
            try {
                tv("نسخ الفيديو…")
                val input = File(work, "input.mp4")
                contentResolver.openInputStream(uri)?.use { ins -> FileOutputStream(input).use { outs -> ins.copyTo(outs) } }
                    ?: throw IllegalStateException("تعذر قراءة الفيديو")
                val frames = File(work, "frames").apply { mkdirs() }
                val sticker = File(work, "sticker.webp")
                val audio = File(work, "audio.m4a")
                val c = crop.getCrop()
                val cropExpr = "crop=iw*${c.width}:ih*${c.height}:iw*${c.left}:ih*${c.top}"
                val frameCmd = "-ss ${start / 1000.0} -t ${(end-start)/1000.0} -i \"${input.absolutePath}\" -vf \"fps=15,$cropExpr,scale=512:512:flags=lanczos,format=rgba\" -an -y \"${frames.absolutePath}/f_%04d.png\""
                tv("استخراج الإطارات…")
                val fs = FFmpegKit.execute(frameCmd)
                if (fs.returnCode?.value != 0) throw IllegalStateException("فشل استخراج الإطارات: ${(fs.allLogsAsString ?: "").takeLast(500)}")

                val audioCmd = "-ss ${start / 1000.0} -t ${(end-start)/1000.0} -i \"${input.absolutePath}\" -vn -c:a aac -b:a 64k -y \"${audio.absolutePath}\""
                tv("استخراج الصوت…")
                val asession = FFmpegKit.execute(audioCmd)
                val hasAudio = asession.returnCode?.value == 0 && audio.exists() && audio.length() > 0

                val frameFiles = (frames.listFiles() ?: emptyArray()).filter { it.extension == "png" }.sortedBy { it.name }
                if (frameFiles.isEmpty()) throw IllegalStateException("لم يتم إنتاج إطارات")
                tv("ضغط الستيكر…")
                val attempts = listOf(15 to 78, 12 to 64, 10 to 52, 8 to 42)
                var resultSize = 0
                for ((fps, q) in attempts) {
                    val wanted = max(2, ((end - start) / 1000.0 * fps).toInt())
                    val selected = if (wanted >= frameFiles.size) frameFiles else List(wanted) { i ->
                        frameFiles[(i.toDouble() * (frameFiles.size - 1) / max(1, wanted - 1)).roundToInt()]
                    }
                    val stills = selected.map { encodeStill(it, q) }
                    val frameDuration = max(40, ((end-start).toDouble()/selected.size).toInt())
                    val data = AnimatedWebp.mux(stills, 512, 512, frameDuration)
                    sticker.writeBytes(data); resultSize = data.size
                    if (resultSize <= 500 * 1024) break
                }
                if (resultSize > 500 * 1024) tv("تنبيه: الحجم ${resultSize/1024}KB، حاول مقطعاً أقصر إذا رفضه التطبيق.")
                val savedName = nameInput.text.toString().trim().ifEmpty { "Sticker ${LibraryStore.list(this@VideoEditorActivity).size + 1}" }
                val saved = if (hasAudio) LibraryStore.add(this@VideoEditorActivity, savedName, sticker, audio) else LibraryStore.addStickerOnly(this@VideoEditorActivity, savedName, sticker)
                withContext(Dispatchers.Main) {
                    tvProgress.text = if (hasAudio) "تم الحفظ: ${saved.name} • ${resultSize/1024}KB • صوت مرتبط" else "تم الحفظ: ${saved.name} • بدون صوت (الفيديو لا يحتوي صوتاً)"
                    setResult(RESULT_OK); finish()
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { tvProgress.text = "فشل الإنشاء: ${e.message}"; btnCreate.isEnabled = true }
            } finally { work.deleteRecursively() }
        }
    }

    @Suppress("DEPRECATION")
    private fun encodeStill(png: File, quality: Int): ByteArray {
        val bitmap = android.graphics.BitmapFactory.decodeFile(png.absolutePath) ?: error("تعذر قراءة الإطار")
        return try { val out = java.io.ByteArrayOutputStream(); val fmt = if (android.os.Build.VERSION.SDK_INT >= 30) android.graphics.Bitmap.CompressFormat.WEBP_LOSSY else android.graphics.Bitmap.CompressFormat.WEBP; bitmap.compress(fmt, quality, out); out.toByteArray() } finally { bitmap.recycle() }
    }

    private fun tv(s: String) = runOnUiThread { tvProgress.text = s }
    private fun fmt(ms: Long): String = String.format(Locale.US, "%.2fs", ms / 1000.0)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(if (w < 0) w else dp(w), if (h < 0) h else dp(h))

    class TimelineRangeView(context: android.content.Context) : View(context) {
        var startMs = 0L; var endMs = 8000L; private var duration = 8000L; private var playhead = 0L
        var onChanged: ((Long, Long) -> Unit)? = null
        private var active = 0
        fun setDuration(d: Long) { duration = max(500L, d); endMs = min(8000L, duration); invalidate(); onChanged?.invoke(startMs, endMs) }
        fun setPlayhead(p: Long) { playhead = p.coerceIn(0, duration); invalidate() }
        fun nudge(delta: Long) { val n = (playhead + delta).coerceIn(startMs, endMs); playhead=n; invalidate() }
        override fun onDraw(c: android.graphics.Canvas) { super.onDraw(c); val w=width.toFloat(); val y=height/2f; val pad=24f; val x0=pad; val x1=w-pad; val span=x1-x0; val sx=x0+span*startMs/duration; val ex=x0+span*endMs/duration; val px=x0+span*playhead/duration; val p=android.graphics.Paint(1); p.strokeWidth=10f; p.color=Color.LTGRAY; c.drawLine(x0,y,x1,y,p); p.color=Color.rgb(76,175,80); c.drawLine(sx,y,ex,y,p); p.color=Color.DKGRAY; c.drawCircle(sx,y,16f,p); c.drawCircle(ex,y,16f,p); p.color=Color.BLACK; c.drawCircle(px,y,6f,p) }
        override fun onTouchEvent(e: MotionEvent): Boolean { val pad=24f; val span=width-pad*2; val t=((e.x-pad)/span*duration).toLong().coerceIn(0,duration); if(e.action==MotionEvent.ACTION_DOWN){ active=if(abs(t-startMs)<=abs(t-endMs))1 else 2; return true }; if(e.action==MotionEvent.ACTION_MOVE||e.action==MotionEvent.ACTION_UP){ if(active==1) startMs=min(t,endMs-500); else endMs=max(t,startMs+500); if(endMs-startMs>8000) { if(active==1) startMs=endMs-8000 else endMs=startMs+8000 }; startMs=startMs.coerceAtLeast(0); endMs=endMs.coerceAtMost(duration); playhead=if(active==1)startMs else min(playhead,endMs); onChanged?.invoke(startMs,endMs); invalidate(); return true }; return true }
    }

    class CropOverlayView(context: android.content.Context) : View(context) {
        private var aspect=1f; private var left=0f; private var top=0f; private var size=0f; private var downX=0f; private var downY=0f; private var mode=0
        fun setVideoAspect(a: Float){aspect=a; reset()}
        fun reset(){ val r=contentRect(); size=min(r.width(),r.height())*.7f; left=r.centerX()-size/2f; top=r.centerY()-size/2f; invalidate() }
        override fun onSizeChanged(w:Int,h:Int,oldw:Int,oldh:Int){ super.onSizeChanged(w,h,oldw,oldh); if(w>0&&h>0&&size==0f) reset() }
        fun getCrop(): Crop { val r=contentRect(); return Crop(((left-r.left)/r.width()).coerceIn(0f,1f),((top-r.top)/r.height()).coerceIn(0f,1f),(size/r.width()).coerceIn(.05f,1f),(size/r.height()).coerceIn(.05f,1f)) }
        data class Crop(val left:Float,val top:Float,val width:Float,val height:Float)
        private fun contentRect(): android.graphics.RectF { val vw=width.toFloat(); val vh=height.toFloat(); val ca=vw/vh; return if(ca>aspect){ val h=vh; val w=h*aspect; android.graphics.RectF((vw-w)/2,0f,(vw+w)/2,h) } else { val w=vw; val h=w/aspect; android.graphics.RectF(0f,(vh-h)/2,w,(vh+h)/2) } }
        override fun onDraw(c: android.graphics.Canvas){ val r=contentRect(); val maxSize=min(r.width(),r.height()); size=size.coerceIn(maxSize*.15f,maxSize); left=left.coerceIn(r.left,r.right-size); top=top.coerceIn(r.top,r.bottom-size); val p=android.graphics.Paint(1); p.color=0x88000000.toInt(); p.style=android.graphics.Paint.Style.FILL; c.drawRect(r.left,r.top,r.right,top,p); c.drawRect(r.left,top,left,bottom(),p); c.drawRect(left+size,top,r.right,bottom(),p); c.drawRect(r.left,bottom(),r.right,r.bottom,p); p.color=Color.WHITE;p.style=android.graphics.Paint.Style.STROKE;p.strokeWidth=5f;c.drawRect(left,top,left+size,top+size,p);p.style=android.graphics.Paint.Style.FILL;c.drawCircle(left+size,top+size,18f,p) }
        private fun bottom()=top+size
        override fun onTouchEvent(e:MotionEvent):Boolean{ when(e.action){MotionEvent.ACTION_DOWN->{downX=e.x;downY=e.y;mode=if(abs(e.x-(left+size))<45&&abs(e.y-(top+size))<45)2 else if(e.x in left..left+size&&e.y in top..top+size)1 else 0;return true};MotionEvent.ACTION_MOVE->{val r=contentRect();if(mode==1){val dx=e.x-downX;val dy=e.y-downY;left=(left+dx).coerceIn(r.left,r.right-size);top=(top+dy).coerceIn(r.top,r.bottom-size);downX=e.x;downY=e.y;invalidate()}else if(mode==2){val ns=(size+(e.x-downX)).coerceIn(min(r.width(),r.height())*.15f,min(r.width(),r.height()));left=(left-(ns-size)/2).coerceIn(r.left,r.right-ns);top=(top-(ns-size)/2).coerceIn(r.top,r.bottom-ns);size=ns;downX=e.x;downY=e.y;invalidate()};return true}};return true}
    }
}
