package com.example.stickerkeyboard

import android.content.Context
import java.io.File

data class LibraryItem(
    val id: String,
    val name: String,
    val webp: File,
    val audio: File
)

/** Saves each sticker together with its sound in its own folder under files/library. */
object LibraryStore {

    private fun root(context: Context): File {
        val dir = File(context.filesDir, "library")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun list(context: Context): List<LibraryItem> {
        val folders = root(context).listFiles() ?: return emptyList()
        val items = ArrayList<LibraryItem>()
        for (folder in folders) {
            if (!folder.isDirectory) continue
            val webp = File(folder, "sticker.webp")
            val audio = File(folder, "audio.m4a")
            if (!webp.exists()) continue
            val nameFile = File(folder, "name.txt")
            val savedName = if (nameFile.exists()) nameFile.readText().trim() else ""
            val name = if (savedName.isEmpty()) folder.name else savedName
            items.add(LibraryItem(folder.name, name, webp, audio))
        }
        items.sortByDescending { it.webp.lastModified() }
        return items
    }

    fun add(context: Context, name: String, webp: File, audio: File): LibraryItem {
        val id = "s" + System.currentTimeMillis()
        val folder = File(root(context), id)
        folder.mkdirs()
        val newWebp = File(folder, "sticker.webp")
        val newAudio = File(folder, "audio.m4a")
        webp.copyTo(newWebp, true)
        audio.copyTo(newAudio, true)
        File(folder, "name.txt").writeText(name)
        return LibraryItem(id, name, newWebp, newAudio)
    }

    fun addStickerOnly(context: Context, name: String, webp: File): LibraryItem {
        val id = "s" + System.currentTimeMillis()
        val folder = File(root(context), id)
        folder.mkdirs()
        val newWebp = File(folder, "sticker.webp")
        val placeholder = File(folder, "audio.m4a")
        webp.copyTo(newWebp, true)
        File(folder, "name.txt").writeText(name)
        return LibraryItem(id, name, newWebp, placeholder)
    }

    fun delete(context: Context, id: String) {
        File(root(context), id).deleteRecursively()
    }
}
